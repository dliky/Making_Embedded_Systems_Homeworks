/*
 * version.h
 *
 *  Created on: 29 avr. 2022
 *      Author: epo
 */

#ifndef VERSION_H
#define VERSION_H

#define VERSION_STRING "ReusableCode 0.0.0.1"

#endif // VERSION_H
