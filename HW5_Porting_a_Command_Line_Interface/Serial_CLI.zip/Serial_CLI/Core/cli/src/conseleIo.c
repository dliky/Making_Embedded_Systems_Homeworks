/*
 * conselelo.c
 *
 *  Created on: 29 avr. 2022
 *      Author: epo
 */

// Console IO is a wrapper between the actual in and output and the console code
// In an embedded system, this might interface to a UART driver.

#include "consoleIo.h"
#include "console.h"
#include "main.h"
#include <string.h>
//#include <stdio.h>
//#include "stm32l4xx_hal.h"

extern UART_HandleTypeDef huart3;

eConsoleError ConsoleIoInit(void)
{
	return CONSOLE_SUCCESS;
}

// This is modified for the Wokwi RPi Pico simulator. It works fine
// but that's partially because the serial terminal sends all of the
// characters at a time without losing any of them. What if this function
// wasn't called fast enough?
eConsoleError ConsoleIoReceive(uint8_t *buffer, const uint32_t bufferLength, uint32_t *readLength)
{
	uint32_t i = 0;
	uint8_t charIn[1];

	while (__HAL_UART_GET_FLAG(&huart3, UART_FLAG_RXNE))
		{
			HAL_UART_Receive(&huart3, charIn, 1, 100);
			HAL_UART_Transmit(&huart3, (uint8_t*)charIn, 1, 100); // echo
			buffer[i] = charIn[0];
			i++;
		}

	*readLength = i;
	return CONSOLE_SUCCESS;
}

eConsoleError ConsoleIoSendString(const char *buffer)
{
	HAL_UART_Transmit(&huart3, (uint8_t*)buffer, strlen(buffer), 100);
	return CONSOLE_SUCCESS;
}
